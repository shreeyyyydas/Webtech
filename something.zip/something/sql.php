<?php
$un = $_POST['u'];
$pd = $_POST['p'];
$con = 0;

// Create connection using mysqli
$conn = new mysqli("localhost", "root", "nik@123N", "vaidoo");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Select all users
$sql = "SELECT name, password FROM riya";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($un == $row["name"] && $pd == $row["password"]) {
            $con = 1;
            break;
        }
    }
}

if ($con == 1) {
    echo "<font color='blue' size='5' align='center'>Welcome to this pc</font>";
} else {
    echo "<font color='red' size='5' align='center'>Invalid Username or Password</font>";
}

$conn->close();
?>
